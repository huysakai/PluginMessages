<?php

namespace Aro;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;

class Main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("[sv] §cĐã hoạt động!");
	}
	
	public function onDisable(){
		$this->getLogger()->info("[sv] Đã dừng!");
	}
	
	public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
		switch($cmd->getName()){
			case "server":
			   $sender->sendMessage("§r§a-=§e|§c♦§e| §aServer§e |§c♦§e|§a=-");
			   $sender->sendMessage("§a∘ §bnhấn vào NPC để play");
			   $sender->sendMessage("§a∘ §dnhấn /napthe để xem cách nạp");
			   $sender->sendMessage("§a∘ §aChúc bạn chơi vui vẻ");
			   $sender->sendMessage("§e-------------------------");
			   return true;
			case "helps":
			   $sender->sendMessage("§r§a-=§e|§c♦§e| §aHelps§e |§c♦§e|§a=-");
			   $sender->sendMessage("§a∘ §b/lag");
			   $sender->sendMessage("§a∘ §d/loi");
			   $sender->sendMessage("§a∘ §d/law");
			   $sender->sendMessage("§a∘ §d/info");
			   $sender->sendMessage("§a∘ §d/thongbao");
			   $sender->sendMessage("§a∘ §d/tocao");
			   $sender->sendMessage("§a∘ §aChúc bạn chơi vui vẻ");
			   $sender->sendMessage("§e-------------------------");
			   return true;
			   default:
			   return false;
		}
	}
}